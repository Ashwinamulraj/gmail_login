package com.snow.test;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Gmail_login {
	static
	{
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
	}
	public static void main(String[] args) throws InterruptedException, IOException
	{
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.gmail.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("aa3621413testlogin");
		driver.findElement(By.xpath("//div[@class='VfPpkd-RLmnJb']")).click();
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Testlogin12345");
		driver.findElement(By.xpath("//*[@id='passwordNext']/div/button/div[2]")).click();
		driver.switchTo().frame(0);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@style='user-select: none']")).click();
		
		driver.findElement(By.xpath("//textarea[@name='to']")).sendKeys("aa3621413testlogin@gmail.com");
		driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys("Testingmail");
		driver.findElement(By.xpath("//div[@class='Am Al editable LW-avf tS-tW']")).sendKeys("Hi");
		driver.findElement(By.xpath("//div[@class='T-I J-J5-Ji aoO v7 T-I-atl L3']")).click();
		
		driver.quit();
		Runtime.getRuntime().exec("taskkill /f /im chromedriver.exe");
			
		}
		
	}

